SELECT c.value('@employer', 'varchar(20)') arbetsgivare, name as namn,
DATEDIFF(day, c.value('@startdate', 'varchar(20)'), GETDATE()) as anst�llningsl�ngd,
				(SELECT COUNT(licencenumber) FROM car where car.owner = p.pid) as antalbilar
FROM Person p CROSS APPLY employments.nodes('//employment[not(@enddate)]') AS X(c)