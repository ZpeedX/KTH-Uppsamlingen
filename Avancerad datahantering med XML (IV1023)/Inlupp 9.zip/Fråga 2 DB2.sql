SELECT arbetsgivare, name AS namn, DAYS(CURRENT DATE)-DAYS(start) anst�llningsl�ngd, 
				(SELECT COUNT(licencenumber) FROM car where car.owner = p.pid) as antalbilar
FROM Person p,
	XMLTABLE('$I//employment[not(@enddate)]' PASSING employments AS "I"
					  COLUMNS
					  arbetsgivare	VARCHAR(20)	PATH '@employer',
					  start			VARCHAR(20) PATH '@startdate'
					  )