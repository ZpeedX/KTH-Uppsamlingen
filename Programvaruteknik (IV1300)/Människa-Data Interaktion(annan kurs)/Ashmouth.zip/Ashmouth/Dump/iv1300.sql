-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 05 okt 2016 kl 13:48
-- Serverversion: 5.7.11
-- PHP-version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `iv1300`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `anställd`
--

CREATE TABLE `anställd` (
  `ID` int(11) NOT NULL,
  `företag` int(11) NOT NULL,
  `förnamn` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `efternamn` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `telefonnummer` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `email` varchar(45) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `anställd`
--

INSERT INTO `anställd` (`ID`, `företag`, `förnamn`, `efternamn`, `telefonnummer`, `email`) VALUES
(16, 1, 'Arvid', 'Arvidsson', '05045345005', 'arre@barre.com'),
(17, 2, 'Bertil', 'Bertilsson', '4723748831', 'barre@arre.com'),
(18, 3, 'Davieee', 'Weeieiiiiei', '0504345005', 'ggwp@barre.com'),
(19, 4, 'Cesar', 'Milan', '+105045345005', 'milan@dogwhisperer.com'),
(20, 5, 'Elisabeth', 'Lundvall', '05045005', 'bettan@teamkthadmins.com'),
(21, 1, 'Bengt', 'Koren', '112', 'bengt@bengt.bengt'),
(22, 2, 'Nikos', 'Eriksson', '12345', 'nikos@nicke.nyfiken'),
(23, 3, 'Sven', 'Dimitrakas', '98765', 'svenne@banan.se'),
(24, 4, 'Cher', 'Chersson', '56789', 'cher@cher.com'),
(25, 5, 'Sixten', 'Olsson', '01359', 'six@ten.com');

-- --------------------------------------------------------

--
-- Tabellstruktur `anställdresa`
--

CREATE TABLE `anställdresa` (
  `ID` int(11) NOT NULL,
  `Anställd` int(11) NOT NULL,
  `Resa` int(11) NOT NULL,
  `Antal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `anställdresa`
--

INSERT INTO `anställdresa` (`ID`, `Anställd`, `Resa`, `Antal`) VALUES
(2, 16, 1, 2),
(13, 16, 6, 3),
(12, 17, 1, 2),
(9, 18, 9, 4),
(5, 19, 5, 5),
(15, 19, 9, 5),
(8, 20, 6, 3),
(1, 20, 10, 1),
(4, 21, 4, 4),
(7, 22, 8, 2),
(6, 23, 7, 1),
(14, 24, 4, 4),
(10, 24, 5, 5),
(3, 25, 2, 3),
(11, 25, 7, 1);

-- --------------------------------------------------------

--
-- Tabellstruktur `fordon`
--

CREATE TABLE `fordon` (
  `ID` int(11) NOT NULL,
  `namn` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `Kilometerutsläpp` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `fordon`
--

INSERT INTO `fordon` (`ID`, `namn`, `Kilometerutsläpp`) VALUES
(1, 'gång', 0),
(10, 'cykel', 0),
(11, 'Bil', 0.193),
(12, 'Miljöbil', 0.106),
(13, 'Motorcykel', 0.146),
(14, 'Moped', 0.056),
(15, 'Buss', 0.0077),
(16, 'Tunnelbana', 0.000004),
(17, 'Tåg', 0.0000058),
(18, 'Flygplan', 0.15);

-- --------------------------------------------------------

--
-- Tabellstruktur `företag`
--

CREATE TABLE `företag` (
  `ID` int(11) NOT NULL,
  `namn` varchar(45) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci COMMENT='Tabell om företagen för de anställda';

--
-- Dumpning av Data i tabell `företag`
--

INSERT INTO `företag` (`ID`, `namn`) VALUES
(1, 'ABB'),
(3, 'Ford'),
(4, 'GB'),
(2, 'Scania'),
(5, 'Volvo');

-- --------------------------------------------------------

--
-- Tabellstruktur `resa`
--

CREATE TABLE `resa` (
  `ID` int(11) NOT NULL,
  `Sträcka` int(11) NOT NULL,
  `Fordon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `resa`
--

INSERT INTO `resa` (`ID`, `Sträcka`, `Fordon`) VALUES
(1, 1, 1),
(6, 1, 10),
(2, 2, 12),
(7, 2, 14),
(5, 3, 18),
(8, 4, 15),
(3, 4, 16),
(10, 5, 13),
(9, 5, 17),
(4, 5, 18);

-- --------------------------------------------------------

--
-- Tabellstruktur `sträcka`
--

CREATE TABLE `sträcka` (
  `ID` int(11) NOT NULL,
  `Kilometer` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `sträcka`
--

INSERT INTO `sträcka` (`ID`, `Kilometer`) VALUES
(1, 2.6),
(2, 7.8),
(4, 9.7),
(5, 323),
(3, 456);

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `anställd`
--
ALTER TABLE `anställd`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `telefonnummer_UNIQUE` (`telefonnummer`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `FK_anställd_företag_idx` (`företag`);

--
-- Index för tabell `anställdresa`
--
ALTER TABLE `anställdresa`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `AN1` (`Anställd`,`Resa`,`Antal`),
  ADD KEY `FK_ar_resa_idx` (`Resa`);

--
-- Index för tabell `fordon`
--
ALTER TABLE `fordon`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `namn_UNIQUE` (`namn`);

--
-- Index för tabell `företag`
--
ALTER TABLE `företag`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `namn_UNIQUE` (`namn`);

--
-- Index för tabell `resa`
--
ALTER TABLE `resa`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `AN1` (`Sträcka`,`Fordon`),
  ADD KEY `FK_resa_fordon_idx` (`Fordon`);

--
-- Index för tabell `sträcka`
--
ALTER TABLE `sträcka`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `kilometer_UNIQUE` (`Kilometer`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `anställd`
--
ALTER TABLE `anställd`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT för tabell `anställdresa`
--
ALTER TABLE `anställdresa`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT för tabell `fordon`
--
ALTER TABLE `fordon`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT för tabell `företag`
--
ALTER TABLE `företag`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT för tabell `resa`
--
ALTER TABLE `resa`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT för tabell `sträcka`
--
ALTER TABLE `sträcka`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `anställd`
--
ALTER TABLE `anställd`
  ADD CONSTRAINT `FK_anställd_företag` FOREIGN KEY (`företag`) REFERENCES `företag` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restriktioner för tabell `anställdresa`
--
ALTER TABLE `anställdresa`
  ADD CONSTRAINT `FK_ar_anställd` FOREIGN KEY (`Anställd`) REFERENCES `anställd` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_ar_resa` FOREIGN KEY (`Resa`) REFERENCES `resa` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restriktioner för tabell `resa`
--
ALTER TABLE `resa`
  ADD CONSTRAINT `FK_resa_fordon` FOREIGN KEY (`Fordon`) REFERENCES `fordon` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_resa_sträcka` FOREIGN KEY (`Sträcka`) REFERENCES `sträcka` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
