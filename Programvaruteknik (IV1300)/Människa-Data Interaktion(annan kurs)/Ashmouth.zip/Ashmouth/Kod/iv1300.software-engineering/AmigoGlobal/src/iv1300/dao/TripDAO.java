package iv1300.dao;

import iv1300.model.Distance;
import iv1300.model.Vehicle;
import iv1300.util.SqlConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

/**
 * Created by Christoffer on 2016-09-26.
 */
public class TripDAO {

    private static TripDAO instance = new TripDAO();

    private TripDAO() {
    }

    /**
     * The only way of reaching the singleton instance.
     *
     * @return the singleton instance of this class
     */
    public static TripDAO getInstance() {
        return instance;
    }

    /**
     * <br>
     * The local instance of the connection to the
     * database retrieved from {@link SqlConnection}.
     */
    private Connection connection = SqlConnection.getInstance().getCon();

    /**
     * Fetches all of the vehicles from the database through the {@link #connection}.
     *
     * @return an an {@link ObservableList ObservableList&lt;E&gt;} containing instances
     * of {@link Vehicle}.
     */
    public ObservableList<Vehicle> getVehicles() {
        ObservableList<Vehicle> vehicles = FXCollections.observableArrayList();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM fordon");

            while (resultSet.next()) {
                vehicles.add(new Vehicle(resultSet.getInt("id"),
                        resultSet.getString("namn"),
                        resultSet.getFloat("kilometerutsläpp")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vehicles;
    }

    /**
     * Fetches a specific distance given an actual distance in kilometers.
     * This is done by querying the database through the {@link #connection}.
     *
     * @param distance the distance in kilometers.
     * @return If the distance was found return a {@link Distance} object
     * corresponding to the fetched data. If not, <code style="color: orange">null</code>
     * will be returned.
     */
    public Distance getDistance(float distance) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM sträcka " +
                    "WHERE ABS(kilometer - ?) < 0.001");

            preparedStatement.setFloat(1, distance);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                return new Distance(resultSet.getInt("id"),
                        resultSet.getFloat("kilometer"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Inserts a distance into the database through the {@link #connection}.
     *
     * @param distance the distance in kilometers.
     * @return the id of the newly inserted distance. If the id couldn't
     * be fetched <code>-<code style="color: #6897BB;">1</code></code> is returned.
     */
    public int addDistance(float distance) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO sträcka (kilometer) VALUES (?)",
                    Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setFloat(1, distance);

            preparedStatement.executeUpdate();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Inserts a trip into the database through the {@link #connection}.
     *
     * @param distId the id of the distance.
     * @param vehicleId the id of the vehicle.
     * @return the id of the newly inserted trip. If the id couldn't
     * be fetched <code>-<code style="color: #6897BB;">1</code></code> is returned.
     */
    public int insertTrip(int distId, int vehicleId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO resa (sträcka, fordon) VALUES (?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setInt(1, distId);
            preparedStatement.setInt(2, vehicleId);

            preparedStatement.executeUpdate();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Fetches a trip from the database through {@link #connection}.
     *
     * @param distId the id of the distance.
     * @param vehicleId the id of the vehicle.
     * @return the id of the fetched trip. If no trip matches
     * with the given input <code>-<code style="color: #6897BB;">1</code></code> is returned.
     */
    public int getTrip(int distId, int vehicleId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT id FROM resa " +
                    "WHERE sträcka = ? AND fordon = ?");

            preparedStatement.setInt(1, distId);
            preparedStatement.setInt(2, vehicleId);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                return resultSet.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Checks with the database through the {@link #connection} if
     * a trip already exists for an employee.
     *
     * @param employeeId the id of the employee.
     * @param tripId the id of the trip.
     * @return <code style="color: orange;">true</code> if such a trip exists.
     * Otherwise <code style="color: orange;">false</code>
     */
    public boolean employeeTripExists(int employeeId, int tripId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM anställdresa " +
                    "WHERE anställd = ? AND resa= ?");

            preparedStatement.setInt(1, employeeId);
            preparedStatement.setInt(2, tripId);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Inserts a trip for an employee into the database through the {@link #connection}.
     *
     * @param employeeId the id of the employee.
     * @param tripId the id of the trip.
     * @param times the number of times the trip has been traveled.
     * @return the id of the newly inserted entry. If the id couldn't
     * be fetched <code>-<code style="color: #6897BB;">1</code></code> is returned.
     */
    public int insertEmployeeTrip(int employeeId, int tripId, int times) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO anställdresa (anställd,resa,antal) " +
                    "VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setInt(1, employeeId);
            preparedStatement.setInt(2, tripId);
            preparedStatement.setInt(3, times);

            preparedStatement.executeUpdate();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
