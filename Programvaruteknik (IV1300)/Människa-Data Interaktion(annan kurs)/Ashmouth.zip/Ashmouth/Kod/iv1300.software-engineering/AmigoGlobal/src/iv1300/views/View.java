package iv1300.views;

import iv1300.controllers.Controller;
import iv1300.model.*;
import iv1300.util.DBTypeValidation;
import iv1300.util.SqlConnection;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;

/**
 * Created by arvid on 2016-09-20.
 */
public class View extends Application {

    private static Controller controller;

    private TableView<Company> companyTable;
    private TableView<Employee> employeeTable;

    private Stage window;
    private Scene scene1, scene2, scene3, scene4;

    private ComboBox<Company> companyCombo;
    private BorderPane borderpane1;
    private VBox scene1leftMenu;
    private VBox scene1RightTableBox;
    private HBox addButtons;

    private GridPane companyGridPane;
    private TextField companyTextField;

    private GridPane employeeGridPane;
    private TextField firstNameTextField;
    private TextField lastNameTextField;
    private TextField phoneNumberTextField;
    private TextField eMailTextField;
    private Label firstName;
    private Label lastName;
    private Label phoneNumber;
    private Label eMail;
    private Button addEmployeeBtn;
    private ComboBox<Company> scene3CompanyDrop;

    private GridPane tripGridPane;
    private TextField distanceTextField;
    private TextField timesTextField;
    private Label distance;
    private Label times;
    private Button addTripBtn;
    private ComboBox<Company> scene4CompanyDrop;
    private ComboBox<Employee> scene4EmployeeDrop;
    private ComboBox<Vehicle> scene4VehicleDrop;

    private Alert alert;

    /**
     * Method for starting the applications only view.
     * This method searches for the {@link #start(Stage)}
     * method inherited by {@link javafx.application.Application}.
     */
    public static void startView() {
        launch();
    }

    /*For documentation on method see javafx.application.Application*/
    /**
     * @param primaryStage the primary stage for this application,
     *                     onto which the application scene can be set.
     *                     The primary stage will be embedded in the browser
     *                     if the application was launched as an applet.
     *                     Applications may create other stages, if needed,
     *                     but they will not be primary stages and will not
     *                     be embedded in the browser.
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        window.setTitle("Ashmouth Technologies");
        primaryStage.setTitle("Ashmouth Technologies");

        window.setOnCloseRequest(e -> closeProgram());

        alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Inmatningsfel");
        alert.setHeaderText("Fel vid inmatning:");

        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image(getClass().getResourceAsStream("images/icon.png")));

        Label labelScene1 = new Label();
        labelScene1.setText("Ashmouth Technologies alpha v0.1");
        labelScene1.setFont(Font.font("Verdana", 20));

        scene1leftMenu = new VBox(20);
        scene1leftMenu.setPadding(new Insets(20, 20, 20, 20));

        scene1RightTableBox = new VBox();

        Button addCompanyBtn = new Button("Lägg till företag");
        addCompanyBtn.setOnAction(e -> switchToScene2());
        Button addEmployeeBtn = new Button("Lägg till anställd");
        addEmployeeBtn.setOnAction(event -> switchToScene3());
        Button addTripBtn = new Button("Lägg till resa");
        addTripBtn.setOnAction(event -> switchToScene4());

        addButtons = new HBox(20);
        addButtons.getChildren().addAll(addCompanyBtn, addEmployeeBtn, addTripBtn);
        addButtons.setAlignment(Pos.CENTER);

        addButtons.setPadding(new Insets(0, 0, 25, 0));

        Button s1q1 = new Button("Avsluta");
        s1q1.setOnAction(e -> closeProgram());

        createCompanyDropDown();

        scene1leftMenu.getChildren().addAll(labelScene1, s1q1, companyCombo);

        BorderPane leftSide = new BorderPane();
        leftSide.setTop(scene1leftMenu);
        leftSide.setBottom(addButtons);

        createCompanyTable();
        updateCompanyTable();
        scene1RightTableBox.getChildren().add(companyTable);

        createEmployeeTable();

        borderpane1 = new BorderPane();
        borderpane1.setLeft(leftSide);
        borderpane1.setCenter(scene1RightTableBox);

        scene1 = new Scene(borderpane1, 1000, 700);
        scene1.getStylesheets().add(this.getClass().getResource("css/style.css").toExternalForm());

        createScene2();
        createScene3();
        createScene4();

        window.getIcons().add(new Image(getClass().getResourceAsStream("images/icon.png")));
        window.setMinHeight(700);
        window.setMinWidth(1000);
        window.setScene(scene1);
        window.show();
    }

    /**
     * Used for assigning value to the {@link #controller}
     * instance for the application.
     *
     * @param controller a controller that can handle the calls
     *                   described by {@link iv1300.controllers.Controller}
     */
    public void setController(Controller controller) {
        this.controller = controller;
    }

    /**
     * Makes the <code>primaryStage</code> (in this application {@link #window})
     * switch context to {@link #scene1} where the summary of
     * companies and their employees are available.
     */
    private void switchToScene1() {
        window.setScene(scene1);
    }

    /**
     * Prepares {@link #scene2} with all of it's components.
     * This scene allows the user to add a company to the
     * database.
     */
    private void createScene2() {
        BorderPane container = new BorderPane();

        companyGridPane = new GridPane();

        Label companyNameLabel = new Label("Företagets namn:");

        companyTextField = new TextField();

        Button btn = new Button("Lägg till");
        btn.setOnAction(e -> addCompany());

        companyGridPane.add(companyNameLabel, 0, 0);
        companyGridPane.add(companyTextField, 0, 1);
        companyGridPane.add(btn, 1, 1);

        companyGridPane.setHgap(10);
        companyGridPane.setVgap(5);

        companyGridPane.setAlignment(Pos.CENTER);

        Button backButton = new Button("Tillbaka");
        backButton.setAlignment(Pos.TOP_CENTER);
        backButton.setOnAction(e -> switchToScene1());

        container.setCenter(companyGridPane);
        container.setLeft(backButton);
        container.setPadding(new Insets(10, 10, 10, 10));

        scene2 = new Scene(container);
    }

    /**
     * Makes the <code>primaryStage</code> (in this application {@link #window})
     * switch context to {@link #scene2} where the ability to add a
     * company is available.
     */
    private void switchToScene2() {
        window.setScene(scene2);
    }

    /**
     * Checks that user input is correct so that the company
     * can be added to the database through the applications {@link #controller}.
     * This method also updates the necessary components for
     * making the view display the added data.
     */
    private void addCompany() {
        String name = companyTextField.getText();
        if (!DBTypeValidation.validDBString(name)) {
            alert.setContentText("Det angivna företagsnamnet är ej giltigt. \n" +
                    "Företagets namn måste bestå av mist ett tecken. \n" +
                    "Namnet får inte börja med ett mellanslag. \n" +
                    "Namnet får ej överskrida 45 tecken.");
            alert.showAndWait();
        } else {
            boolean exists = false;
            for (Company c : companyCombo.getItems()) {
                if (c.getName().toLowerCase().equals(name.toLowerCase())) {
                    exists = true;
                    alert.setContentText("Det angivna företagsnamnet existerar redan.");
                    alert.showAndWait();
                }
            }
            if (!exists) {
                controller.insertCompany(name);
                Company newComp = controller.getCompany(name);
                companyCombo.getItems().add(newComp);
                scene3CompanyDrop.getItems().add(newComp);
                scene4CompanyDrop.getItems().add(newComp);
                updateCompanyTable();
                companyTextField.clear();
                switchToScene1();
            }
        }
    }

    /**
     * Prepares {@link #scene3} with all of it's components.
     * This scene allows the user to add an employee given
     * an existing company.
     */
    private void createScene3() {
        BorderPane container = new BorderPane();

        employeeGridPane = new GridPane();

        firstName = new Label("Förnamn:");
        lastName = new Label("Efternamn:");
        phoneNumber = new Label("Telefonnummer:");
        eMail = new Label("E-mail:");

        firstNameTextField = new TextField();
        lastNameTextField = new TextField();
        phoneNumberTextField = new TextField();
        eMailTextField = new TextField();

        scene3CompanyDrop = new ComboBox();
        scene3CompanyDrop.setId("scene3CompanyDrop");
        scene3CompanyDrop.setPromptText("Anställds företag");

        scene3CompanyDrop.setItems(controller.getAllCompanies());
        scene3CompanyDrop.getSelectionModel().selectedIndexProperty().addListener(
                (observable, oldValue, newValue) -> displayEmployeeInput());

        addEmployeeBtn = new Button("Lägg till");
        addEmployeeBtn.setOnAction(e -> addEmployee());

        employeeGridPane.add(scene3CompanyDrop, 0, 1);

        employeeGridPane.setHgap(10);
        employeeGridPane.setVgap(5);

        employeeGridPane.setAlignment(Pos.CENTER);

        Button backButton = new Button("Tillbaka");
        backButton.setAlignment(Pos.TOP_CENTER);
        backButton.setOnAction(e -> switchToScene1());

        container.setCenter(employeeGridPane);
        container.setLeft(backButton);
        container.setPadding(new Insets(10, 10, 10, 10));

        scene3 = new Scene(container);
    }

    /**
     * Makes the <code>primaryStage</code> (in this application {@link #window})
     * switch context to {@link #scene3} where the ability to add an
     * employee is available.
     */
    private void switchToScene3() {
        window.setScene(scene3);
    }

    /**
     * When a value is selected in {@link #scene3CompanyDrop} the components
     * necessary for input of an employee will be displayed given they aren't
     * already there. This prevents the user from entering information
     * without selecting an existing company.
     */
    private void displayEmployeeInput() {
        if (!employeeGridPane.getChildren().contains(firstName)) {
            employeeGridPane.add(firstName, 1, 0);
            employeeGridPane.add(firstNameTextField, 1, 1);
            employeeGridPane.add(lastName, 1, 2);
            employeeGridPane.add(lastNameTextField, 1, 3);
            employeeGridPane.add(phoneNumber, 1, 4);
            employeeGridPane.add(phoneNumberTextField, 1, 5);
            employeeGridPane.add(eMail, 1, 6);
            employeeGridPane.add(eMailTextField, 1, 7);
            employeeGridPane.add(addEmployeeBtn, 2, 7);
        }
    }

    /**
     * Checks that user input is correct so that the employee
     * can be added to the database through the applications {@link #controller}.
     * This method also updates the necessary components for
     * making the view display the added data as well as resetting
     * the components in {@link #scene3}.
     */
    private void addEmployee() {
        Person person = new Person(firstNameTextField.getText(), lastNameTextField.getText(),
                phoneNumberTextField.getText(), eMailTextField.getText());

        if (!DBTypeValidation.validDBPerson(person)) {
            alert.setContentText("De angivna fälten är ej giltiga. \n" +
                    "Samtliga fält måste inehålla minst ett tecken. \n" +
                    "De får inte börja med ett mellanslag. \n" +
                    "De får ej överskrida 45 tecken.");
            alert.showAndWait();
        } else {
            boolean exists = false;
            List<Employee> employees = controller.getAllEmployees();
            for (Employee e : employees) {
                if (e.getPhoneNumber().toLowerCase().equals(person.getPhoneNumber().toLowerCase())) {
                    exists = true;
                    alert.setContentText("En anställd har redan detta telefonnummer.");
                    alert.showAndWait();
                } else if (e.getEMail().toLowerCase().equals(person.getEMail().toLowerCase())) {
                    exists = true;
                    alert.setContentText("En anställd har redan denna e-mail.");
                    alert.showAndWait();
                }
            }
            if (!exists) {
                Company selected = scene3CompanyDrop.getSelectionModel().getSelectedItem();
                controller.insertEmployee(selected, person);
                if(companyCombo.getSelectionModel().getSelectedIndex() ==
                        scene3CompanyDrop.getSelectionModel().getSelectedIndex()) {
                    displayEmployeesForCompany(selected);
                }
                cleanEmployeInput();
                updateCompanyTable();
                switchToScene1();
            }
        }
    }

    /**
     * Resets the components of {@link #scene3}. The order of
     * the calls are of importance since setting the value to
     * <code>null</code> for {@link #scene3CompanyDrop} will trigger
     * it's added {@link javafx.beans.value.ChangeListener Changelistener}
     * evoking {@link #displayEmployeeInput()}.
     */
    private void cleanEmployeInput() {
        scene3CompanyDrop.setValue(null);
        employeeGridPane.getChildren().remove(1, 10);
        firstNameTextField.clear();
        lastNameTextField.clear();
        phoneNumberTextField.clear();
        eMailTextField.clear();
    }

    /**
     * Prepares {@link #scene4} with all of it's components.
     * This scene allows the user to add a trip for an existing
     * employee.
     */
    private void createScene4() {
        BorderPane container = new BorderPane();

        tripGridPane = new GridPane();

        distance = new Label("Sträcka (kilometer):");
        times = new Label("Antal resor:");

        distanceTextField = new TextField();
        timesTextField = new TextField();

        scene4CompanyDrop = new ComboBox();
        scene4CompanyDrop.setId("drop1");
        scene4CompanyDrop.setPromptText("Anställds företag");

        scene4CompanyDrop.setItems(controller.getAllCompanies());

        scene4CompanyDrop.getSelectionModel().selectedIndexProperty().addListener(
                (observable, oldValue, newValue) -> displayEmployeeDrop(
                        scene4CompanyDrop.getSelectionModel().getSelectedItem()));

        scene4EmployeeDrop = new ComboBox();
        scene4EmployeeDrop.setId("drop2");
        scene4EmployeeDrop.setPromptText("Anställd");

        scene4EmployeeDrop.getSelectionModel().selectedIndexProperty().addListener(
                (observable, oldValue, newValue) -> displayVehicleDrop());

        scene4VehicleDrop = new ComboBox();
        scene4VehicleDrop.setId("drop3");
        scene4VehicleDrop.setPromptText("Fordon");

        scene4VehicleDrop.setItems(controller.getAllVehicles());

        scene4VehicleDrop.getSelectionModel().selectedIndexProperty().addListener(
                (observable, oldValue, newValue) -> displayTripInput());

        addTripBtn = new Button("Lägg till");
        addTripBtn.addEventHandler(ActionEvent.ACTION, e -> addTrip());
        addTripBtn.addEventHandler(ActionEvent.ACTION, e -> switchToScene1());

        tripGridPane.add(scene4CompanyDrop, 0, 1);

        tripGridPane.setHgap(10);
        tripGridPane.setVgap(5);

        tripGridPane.setAlignment(Pos.CENTER);

        Button backButton = new Button("Tillbaka");
        backButton.setAlignment(Pos.TOP_CENTER);
        backButton.setOnAction(e -> switchToScene1());

        container.setCenter(tripGridPane);
        container.setLeft(backButton);
        container.setPadding(new Insets(10, 10, 10, 10));

        scene4 = new Scene(container);
    }

    /**
     * Makes the <code>primaryStage</code> (in this application {@link #window})
     * switch context to {@link #scene4} where the ability to add a
     * trip is available.
     */
    private void switchToScene4() {
        window.setScene(scene4);
    }

    /**
     * When a value is selected in {@link #scene4CompanyDrop} the view will
     * display {@link #scene4EmployeeDrop} containing the associated values.
     */
    private void displayEmployeeDrop(Company company) {
        if(scene4CompanyDrop.getSelectionModel().getSelectedIndex() != -1) {
            scene4EmployeeDrop.setItems(controller.getEmployeesForCompany(company));
        }
        if (!tripGridPane.getChildren().contains(scene4EmployeeDrop))
            tripGridPane.add(scene4EmployeeDrop, 0, 2);
    }

    /**
     * When a value is selected in {@link #scene4EmployeeDrop} the view will
     * display {@link #scene4VehicleDrop} containing the associated values
     * found in the database.
     */
    private void displayVehicleDrop() {
        if (!tripGridPane.getChildren().contains(scene4VehicleDrop)) {
            tripGridPane.add(scene4VehicleDrop, 0, 3);
        }
    }

    /**
     * When a value is selected in {@link #scene4VehicleDrop} the view will
     * display {@link #scene4VehicleDrop} containing the associated values
     * found in the database.
     */
    private void displayTripInput() {
        if (!tripGridPane.getChildren().contains(distance)) {
            tripGridPane.add(distance, 0, 4);
            tripGridPane.add(distanceTextField, 0, 5);
            tripGridPane.add(times, 0, 6);
            tripGridPane.add(timesTextField, 0, 7);
            tripGridPane.add(addTripBtn, 1, 7);
        }
    }

    /**
     * Checks that user input is correct so that the trip
     * can be added to the database through the applications {@link #controller}.
     * This method also updates the necessary components for
     * making the view display the added data as well as resetting
     * the components in {@link #scene4}.
     */
    private void addTrip() {
        if (!DBTypeValidation.validDBDist(distanceTextField.getText())) {
            alert.setContentText("Sträckan måste vara ett positivt decimaltal eller heltal.\n" +
                    "Deimal ges av en punkt och inte ett kommatecken!");
            alert.showAndWait();
        } else if (!DBTypeValidation.validDBTimes(timesTextField.getText())) {
            alert.setContentText("Antalet måste vara ett heltal större än 0.");
            alert.showAndWait();
        } else if (scene4EmployeeDrop.getSelectionModel().getSelectedIndex() == -1) {
            alert.setContentText("En anställd måste vara vald.");
            alert.showAndWait();
        } else {
            float dist = Float.parseFloat(distanceTextField.getText());
            int times = Integer.parseInt(timesTextField.getText());
            int tripId;
            int vehicleId = scene4VehicleDrop.getSelectionModel().getSelectedItem().getId();
            int employeeId = scene4EmployeeDrop.getSelectionModel().getSelectedItem().getId();
            boolean exists = false;

            Distance distance = controller.getDistance(dist);
            if (distance == null) {
                int distId = controller.addDistance(dist);
                tripId = controller.insertTrip(distId, vehicleId);
            } else {
                tripId = controller.getTrip(distance.getId(), vehicleId);
                if (tripId == -1) {
                    tripId = controller.insertTrip(distance.getId(), vehicleId);
                } else if (controller.employeeTripExists(employeeId, tripId)) {
                    exists = true;
                    alert.setContentText("Den valda anställda har redan denna resa.");
                    alert.showAndWait();
                }
            }
            if (!exists) {
                controller.insertEmployeeTrip(employeeId, tripId, times);
                updateCompanyTable();
                if (scene4CompanyDrop.getSelectionModel().getSelectedIndex() ==
                        companyCombo.getSelectionModel().getSelectedIndex()) {
                    displayEmployeesForCompany(companyCombo.getSelectionModel().getSelectedItem());
                }
                cleanTripInput();
                switchToScene1();
            }
        }
    }

    /**
     * Resets the components of {@link #scene4}. The order of
     * the calls (call 1 and 4) are of importance since setting the value to
     * <code>null</code> for {@link #scene4VehicleDrop} will trigger
     * it's added {@link javafx.beans.value.ChangeListener Changelistener}
     * evoking {@link #displayTripInput()}.
     */
    private void cleanTripInput() {
        scene4VehicleDrop.setValue(null);
        scene4EmployeeDrop.setValue(null);
        scene4CompanyDrop.setValue(null);
        tripGridPane.getChildren().remove(1, 8);
        distanceTextField.clear();
        timesTextField.clear();
    }

    /**
     * Prepares {@link #companyCombo} that will be displayed on
     * {@link #scene1}.
     */
    private void createCompanyDropDown() {
        companyCombo = new ComboBox();
        companyCombo.setPromptText("Välj ett företag");

        companyCombo.setItems(controller.getAllCompanies());
        companyCombo.getSelectionModel().selectedIndexProperty().addListener(
                (observable, oldValue, newValue) -> displayEmployeesForCompany(
                        companyCombo.getSelectionModel().getSelectedItem()));
    }

    /**
     *  Evoked by {@link #companyCombo}'s {@link javafx.beans.value.ChangeListener Changelistener}.
     *  Displays information inside {@link #employeeTable} for the employees of
     *  the selected company. The method also makes {@link #employeeTable} appear
     *  in case it isn't already visible to the user.
     *
     * @param company the selected company.
     */
    private void displayEmployeesForCompany(Company company) {
        if (!scene1RightTableBox.getChildren().contains(employeeTable)) {
            scene1RightTableBox.getChildren().add(employeeTable);
        }
        employeeTable.setItems(controller.getEmployeesForCompany(company));
    }

    /**
     * Prepares {@link #companyTable} for displaying instances of
     * {@link Company}.
     */
    private void createCompanyTable() {
        TableColumn<Company, String> nameCol = new TableColumn<>("Namn");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setMinWidth(80);

        TableColumn<Company, Float> totalEmissionCol = new TableColumn<>("Totalt utsläpp");
        totalEmissionCol.setCellValueFactory(new PropertyValueFactory<>("totalEmission"));
        totalEmissionCol.setMinWidth(120);

        TableColumn<Company, Float> averageEmissionCol = new TableColumn<>("Medelutsläpp per person");
        averageEmissionCol.setCellValueFactory(new PropertyValueFactory<>("averageEmission"));
        averageEmissionCol.setMinWidth(150);

        companyTable = new TableView<>();
        companyTable.getColumns().addAll(nameCol, totalEmissionCol, averageEmissionCol);
        companyTable.prefHeightProperty().bind(scene1RightTableBox.heightProperty());
        companyTable.setPlaceholder(new Text("Inga företag att hämta från databasen."));
    }

    /**
     * Refreshes the contents of {@link #companyTable}. All of the data is
     * updated by replacing it with data fetched from the database.
     */
    private void updateCompanyTable() {
        companyTable.setItems(controller.getAllCompanies());
    }

    /**
     * Prepares {@link #employeeTable} for displaying instances of
     * {@link Employee}.
     */
    private void createEmployeeTable() {
        TableColumn<Employee, String> firstNameCol = new TableColumn<>("Förnamn");
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        firstNameCol.setMinWidth(100);

        TableColumn<Employee, String> lastNameCol = new TableColumn<>("Efternamn");
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        lastNameCol.setMinWidth(100);

        TableColumn<Employee, String> phoneNumberCol = new TableColumn<>("Telefonnummer");
        phoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        phoneNumberCol.setMinWidth(120);

        TableColumn<Employee, String> eMailCol = new TableColumn<>("E-mail");
        eMailCol.setCellValueFactory(new PropertyValueFactory<>("eMail"));
        eMailCol.setMinWidth(150);

        TableColumn<Employee, String> totalEmissionCol = new TableColumn<>("Totalt utsläpp");
        totalEmissionCol.setCellValueFactory(new PropertyValueFactory<>("totalEmission"));
        totalEmissionCol.setMinWidth(100);

        employeeTable = new TableView<>();
        employeeTable.getColumns().addAll(firstNameCol, lastNameCol, phoneNumberCol, eMailCol, totalEmissionCol);
        employeeTable.prefHeightProperty().bind(scene1RightTableBox.heightProperty());
        employeeTable.setPlaceholder(new Text("Företaget har inga anställda."));
    }

    /**
     * Closes the application by calling the necessary
     * functions defined by {@link java.sql.Connection} as well
     * as closing the {@link #window}.
     */
    private void closeProgram() {
        try {
            System.out.println("Skickar ändringar till databasen...");
            SqlConnection.getInstance().getCon().commit();
            System.out.println("Stänger SQL anslutningen...");
            SqlConnection.getInstance().getCon().close();
            System.out.println("Stänger fönstret...");
            window.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Kunde inte avsluta applikationen korrekt.");
        }
    }
}