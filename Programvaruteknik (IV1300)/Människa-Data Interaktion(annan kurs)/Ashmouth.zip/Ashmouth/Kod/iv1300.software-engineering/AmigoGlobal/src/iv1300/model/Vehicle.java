package iv1300.model;

/**
 * Created by Christoffer on 2016-10-06.
 */
public class Vehicle {

    private int id;
    private String name;
    private float emissionPerKm;

    /**
     * The constructor for {@link Vehicle}
     *
     * @param id the id of the vehicle.
     * @param name the name of the vehicle.
     * @param emissionPerKm the emission per kilometer for the vehicle.
     */
    public Vehicle(int id, String name, float emissionPerKm) {
        this.id = id;
        this.name = name;
        this.emissionPerKm = emissionPerKm;
    }

    /**
     * @return the id of the instance called upon.
     */
    public int getId() {
        return id;
    }

    /**
     * @return the name of the instance called upon.
     */
    public String getName() {
        return name;
    }

    /**
     * @return the emission per kilometer of the instance called upon.
     */
    public float getEmissionPerKm() {
        return emissionPerKm;
    }

    @Override
    public String toString() {
        return name;
    }
}
