package iv1300.model;

/**
 * Created by Christoffer on 2016-10-08.
 */
public class Person {

    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String eMail;

    /**
     * The constructor for {@link Person}
     *
     * @param firstName the first name of the person.
     * @param lastName the last name of the person.
     * @param phoneNumber the phone number of the person.
     * @param eMail the e mail address of the person.
     */
    public Person(String firstName, String lastName, String phoneNumber, String eMail) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.eMail = eMail;
    }

    /**
     * @return the first name of the instance called upon
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the last name of the instance called upon
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @return the phone number of the instance called upon
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @return the e mail address of the instance called upon
     */
    public String getEMail() { return eMail; }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}
