package iv1300.model;

import iv1300.dao.EmployeeDAO;
import iv1300.dao.TripDAO;
import javafx.collections.ObservableList;

import java.util.List;

/**
 * Created by Christoffer on 2016-09-26.
 */
public class Employee extends Person{

    private int id;

    /**
     * The constructor for {@link Employee}
     *
     * @param id the id of the employee.
     * @param firstName the first name of the employee.
     * @param lastName the last name of the employee.
     * @param phoneNumber the phone number of the employee.
     * @param eMail the e mail address of the employee.
     *
     * @see Person
     */
    public Employee(int id, String firstName, String lastName, String phoneNumber, String eMail) {
        super(firstName, lastName, phoneNumber, eMail);
        this.id = id;
    }

    /**
     * @return the id of the instance called upon.
     */
    public int getId() {
        return id;
    }

    /**
     * @return the total emission of the instance called upon.
     * The value is fetched by querying the database through
     * {@link EmployeeDAO#getTotalEmissionForEmployee(int)}.
     */
    public float getTotalEmission() {
        return EmployeeDAO.getInstance().getTotalEmissionForEmployee(id);
    }
}
