package iv1300.util;

/**
 * Created by arvid on 2016-09-21.
 */
import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class SqlConnection {

    private static SqlConnection sqlCon = new SqlConnection();

    /**
     * The only way of reaching the singleton instance.
     *
     * @return the singleton instance of this class
     */
    public static SqlConnection getInstance() { return sqlCon; }

    private SqlConnection() {
    }

    /**
     * <br>
     * The local instance of the connection to the database.
     */
    private Connection con;

    /**
     * Tries to connect to the database given the input.
     *
     * @param user the username for the database.
     * @param password the password for the database.
     *
     * @see #getCredentials(Boolean)
     */
    private void connect(String user, String password) {
        String URL = "jdbc:mysql:///iv1300";
        String driver = "com.mysql.jdbc.Driver";

        try {
            Class.forName(driver);
            con = DriverManager.getConnection(URL, user, password);
            con.setAutoCommit(false);
            System.out.println("Ansluten till: " + URL + ", genom: " + driver + "\n");
        } catch (Exception e) {
            getCredentials(false);
        }
    }

    /**
     * @return the instance of the connection for the singleton.
     *
     * @see #con
     */
    public Connection getCon() {
        return this.con;
    }

    /**
     * Recursive method checking if username and password
     * are correct for the database.
     *
     * @param b <code style="color: orange;">true</code> if credential
     *          are valid. <code style="color: orange;">false</code> if invalid.
     */
    public void getCredentials(Boolean b) {
        if (b) {
            String user = JOptionPane.showInputDialog("Användarnamn till databas:");
            if (user != null) {
                String password = JOptionPane.showInputDialog("Lösenord till databas:");
                if (password != null) {
                    connect(user, password);
                } else System.exit(0);
            } else System.exit(0);
        } else {
            JOptionPane.showMessageDialog(null, "Fel användarnamn eller lösenord! Försök igen");
            getCredentials(true);
        }
    }
}
