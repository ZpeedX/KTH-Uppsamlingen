package iv1300.util;

import iv1300.model.Person;

/**
 * Created by Christoffer on 2016-10-08.
 */
public class DBTypeValidation {

    /**
     * Method to check if credentials of person (an in turn employee)
     * is suitable for entering into the database.
     *
     * @param person the person which values needs to be checked
     * @return return <code style="color: orange;">true</code> if all
     * of the credentials are allowed values. <code style="color: orange;">false</code>
     * if any of the values don't meet the criteria.
     *
     * @see #validDBString(String)
     */
    public static boolean validDBPerson(Person person) {
        if (!validDBString(person.getFirstName()) || !validDBString(person.getLastName()) ||
                !validDBString(person.getPhoneNumber()) || !validDBString(person.getEMail())) {
            return false;
        }
        return true;
    }

    /**
     * Method to check if a {@link String} is suitable
     * for entering into the database.
     *
     * @param s the string that needs to be checked.
     * @return <code style="color: orange;">true</code> if string is valid.
     * <code style="color: orange;">false</code>
     * if invalid.
     */
    public static boolean validDBString(String s) {
        if (s.length() == 0 || s.charAt(0) == 32 || s.length() > 45) {
            return false;
        }
        return true;
    }

    /**
     * Method to check if a {@link String} represents a
     * suitable distance for entering into the database.
     *
     * @param s the string that needs to be checked.
     * @return <code style="color: orange;">true</code> if string is valid.
     * <code style="color: orange;">false</code>
     * if invalid.
     */
    public static boolean validDBDist(String s) {
        try {
            float f = Float.parseFloat(s);
            if (f < 0) return false;
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    /**
     * Method to check if a {@link String} represents a
     * positive integer value for entering into the database.
     *
     * @param s the string that needs to be checked.
     * @return <code style="color: orange;">true</code> if string is valid.
     * <code style="color: orange;">false</code>
     * if invalid.
     */
    public static boolean validDBTimes(String s) {
        try {
            int i = Integer.parseInt(s);
            if (i < 1) return false;
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
}
