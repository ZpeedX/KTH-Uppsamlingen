package iv1300.controllers;

import iv1300.dao.CompanyDAO;
import iv1300.dao.EmployeeDAO;
import iv1300.dao.TripDAO;
import iv1300.model.*;
import javafx.collections.ObservableList;

import java.util.List;

/**
 * Created by Christoffer on 2016-09-24.
 */
public class Controller {

    /**
     * Fetches all the companies in the database through {@link CompanyDAO#getAll()}.
     *
     * @return an {@link ObservableList ObservableList&lt;E&gt;}
     * of all the companies in the database at the moment of calling the method.
     */
    public ObservableList<Company> getAllCompanies() {
        return CompanyDAO.getInstance().getAll();
    }

    /**
     * Fetches and returns a company from the database through {@link CompanyDAO#getCompany(String)}
     * given the name of the company.
     *
     * @param name the name of the company that should be fetched.
     * @return a {@link Company} if there was an entry in the database matching the
     * given name. Returns <code>{@link null}</code> if no rows match.
     */
    public Company getCompany(String name) {
        return CompanyDAO.getInstance().getCompany(name);
    }

    /**
     * Fetches all employees present in the database through {@link EmployeeDAO#getAll()}.
     *
     * @return a {@link List List&lt;E&gt;} with instances of {@link Employee}.
     */
    public List<Employee> getAllEmployees() {
        return EmployeeDAO.getInstance().getAll();
    }

    /**
     * Fetches an {@link ObservableList ObservableList&lt;E&gt;} containing instances
     * of {@link Employee}<code>'s</code> related to a given {@link Company}. This is
     * done through {@link EmployeeDAO#getEmployeesForCompany(Company)}.
     *
     * @param company the company of the employees.
     * @return an {@link ObservableList ObservableList&lt;E&gt;} containing the
     * employees working for the company.
     */
    public ObservableList<Employee> getEmployeesForCompany(Company company) {
        return EmployeeDAO.getInstance().getEmployeesForCompany(company);
    }

    /**
     * Inserts a company into the database through {@link CompanyDAO#insertCompany(String)}.
     *
     * @param name the name of the company.
     */
    public void insertCompany(String name) {
        CompanyDAO.getInstance().insertCompany(name);
    }

    /**
     * Inserts an employee into the database through {@link EmployeeDAO#insertEmployee(Company, Person)}.
     *
     * @param company the company that the employee is working for.
     * @param person  the credentials of the employee.
     * @return the id of the newly inserted employee.
     */
    public int insertEmployee(Company company, Person person) {
        return EmployeeDAO.getInstance().insertEmployee(company, person);
    }

    /**
     * Fetches all the vehicles present in the database through {@link TripDAO#getVehicles()}.
     *
     * @return an {@link ObservableList ObservableList&lt;E&gt;} containing instances of
     * {@link Vehicle}.
     */
    public ObservableList<Vehicle> getAllVehicles() {
        return TripDAO.getInstance().getVehicles();
    }

    /**
     * Fetches a distance from the database through {@link TripDAO#getDistance(float)}.
     *
     * @param distance the distance in kilometers.
     * @return a {@link Distance} object corresponding to the entered distance
     * if such a distance is present in the database. If not, <code>{@link null}</code> is returned.
     */
    public Distance getDistance(float distance) {
        return TripDAO.getInstance().getDistance(distance);
    }

    /**
     * Inserts a distance into the database through {@link TripDAO#addDistance(float)}.
     *
     * @param distance the distance that is to be inserted.
     * @return the id of the newly inserted distance.
     */
    public int addDistance(float distance) {
        return TripDAO.getInstance().addDistance(distance);
    }

    /**
     * Fetches a trip from the database through {@link TripDAO#getTrip(int, int)}.
     *
     * @param distId the id of the distance preset in the database.
     * @param vehicleId the id of the vehicle present in the database.
     * @return the id of the trip, if present in the database. If not, <code>-1</code> is returned.
     */
    public int getTrip(int distId, int vehicleId) {
        return TripDAO.getInstance().getTrip(distId, vehicleId);
    }

    /**
     * Inserts a trip into the database through {@link TripDAO#insertTrip(int, int)}.
     *
     * @param distId the id of the distance present in the database.
     * @param vehicleId the id of the vehicle present in the database.
     * @return the id of the newly inserted trip.
     */
    public int insertTrip(int distId, int vehicleId) {
        return TripDAO.getInstance().insertTrip(distId, vehicleId);
    }

    /**
     * Contacting the database to see if a trip already exists
     * for a given employee.
     *
     * @param employeeId the id of the employee.
     * @param tripId the id of the trip.
     * @return if the trip exists for the employee: <code>true</code>, otherwise <code>false</code>.
     */
    public boolean employeeTripExists(int employeeId, int tripId) {
        return TripDAO.getInstance().employeeTripExists(employeeId, tripId);
    }

    /**
     * Inserts a trip for a given employee through {@link TripDAO#insertEmployeeTrip(int, int, int)}.
     *
     * @param employeeId the id of the employee.
     * @param tripId the id of the trip.
     * @param times the number of times the trip has been traveled.
     * @return the id of the newly inserted entry.
     */
    public int insertEmployeeTrip(int employeeId, int tripId, int times) {
        return TripDAO.getInstance().insertEmployeeTrip(employeeId, tripId, times);
    }
}
