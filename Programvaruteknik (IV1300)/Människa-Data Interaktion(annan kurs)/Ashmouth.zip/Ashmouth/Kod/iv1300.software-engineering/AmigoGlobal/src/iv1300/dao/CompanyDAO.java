package iv1300.dao;

import iv1300.model.Company;
import iv1300.util.SqlConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Christoffer on 2016-09-26.
 */
public class CompanyDAO {

    private static CompanyDAO instance = new CompanyDAO();

    private CompanyDAO() {
    }

    /**
     * The only way of reaching the singleton instance.
     *
     * @return the singleton instance of this class
     */
    public static CompanyDAO getInstance() {
        return instance;
    }

    /**
     * <br>
     * The local instance of the connection to the
     * database retrieved from {@link SqlConnection}.
     */
    private Connection connection = SqlConnection.getInstance().getCon();

    /**
     * Fetches all of the companies present in the database.
     * This is done through the {@link #connection}.
     *
     * @return an {@link ObservableList ObservableList&lt;E&gt;} containing instances
     * of {@link Company}.
     */
    public ObservableList<Company> getAll() {

        ObservableList<Company> companies = FXCollections.observableArrayList();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM företag");

            while (resultSet.next()) {
                companies.add(new Company(resultSet.getInt("id"),
                        resultSet.getString("namn")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return companies;
    }

    /**
     * Fetches the information of a company in the database through {@link #connection}.
     *
     * @param name the name of the company that is to be retrieved.
     * @return if the name was related to a company in the database
     * the method will return a corresponding {@link Company}. Otherwise {@link null}.
     */
    public Company getCompany(String name) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM företag " +
                                                                              "WHERE namn = ?");
            preparedStatement.setString(1, name);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            return new Company(resultSet.getInt("id"),
                    resultSet.getString("namn"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Inserts a company into the database through the {@link #connection}.
     *
     * @param name the name of the company.
     */
    public void insertCompany(String name) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO företag (namn) VALUES (?)");
            preparedStatement.setString(1, name);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Fetches the total emission produced by a company.
     * The data is retrieved through querying the database
     * through the {@link #connection}
     *
     * @param id the id of the company.
     * @return the total emission for the given company.
     */
    public float getTotalEmissionForCompany(int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT tot " +
                    "FROM (SELECT f.id, SUM((kilometer * kilometerutsläpp * antal)) AS tot " +
                    "FROM Företag AS f, Anställd AS a, Anställdresa AS ar, Resa AS r, Sträcka AS s, Fordon AS v " +
                    "WHERE f.id = företag AND a.id = anställd AND r.id = resa AND s.id = sträcka AND v.id = fordon " +
                    "GROUP BY f.id) AS t1 " +
                    "WHERE id = ?");

            preparedStatement.setInt(1,id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                return resultSet.getFloat(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.f;
    }

    /**
     * Fetches the number of employees working for the given company.
     * The data is retrieved through querying the database
     * through the {@link #connection}
     *
     * @param id the id of the company.
     * @return the number of employees working for the company.
     */
    public int numberOfEmployees(int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT antal " +
                    "FROM (SELECT f.id, COUNT(*) AS antal " +
                    "FROM anställd AS a, företag AS f " +
                    "WHERE f.id = företag " +
                    "GROUP BY f.id) AS t1 " +
                    "WHERE id = ?");

            preparedStatement.setInt(1,id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
