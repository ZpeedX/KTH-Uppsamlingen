package iv1300;

import iv1300.controllers.Controller;
import iv1300.util.SqlConnection;
import iv1300.views.View;

/**
 * Created by Christoffer on 2016-09-22.
 */
public class Startup {

    /**
     * The main method for initializing any vital components as well
     * as starting the whole application.
     *
     * @param args the command-line arguments.
     *             These are currently not used anywhere in the application.
     */
    public static void main(String[] args) {
        SqlConnection.getInstance().getCredentials(true);

        Controller controller = new Controller();

        View v = new View();
        v.setController(controller);
        View.startView();
    }

}