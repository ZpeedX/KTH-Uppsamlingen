package iv1300.model;

import iv1300.dao.CompanyDAO;
import iv1300.dao.EmployeeDAO;
import javafx.collections.ObservableList;

import java.util.List;

/**
 * Created by Christoffer on 2016-09-26.
 */
public class Company {

    private int id;
    private String name;

    /**
     * The constructor for {@link Company}
     *
     * @param id the id of the company.
     * @param name the name of the company.
     */
    public Company(int id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * @return the id of the instance called upon.
     */
    public int getId() { return id; }

    /**
     * @return the name of the instance called upon.
     */
    public String getName() {
        return name;
    }

    /**
     * @return the total emission of the instance called upon.
     * This is done by contacting the database through {@link CompanyDAO#getTotalEmissionForCompany(int)}.
     */
    public float getTotalEmission() {
        return CompanyDAO.getInstance().getTotalEmissionForCompany(id);
    }

    /**
     * @return the average emission of the instance called upon.
     * This is done by querying the database in two steps.
     * Firstly getting the number of employees through {@link CompanyDAO#numberOfEmployees(int)}
     * followed by {@link #getTotalEmission()}. The value is then calculated and returned.
     */
    public float getAverageEmission() {
        int numberOfEmployees = CompanyDAO.getInstance().numberOfEmployees(id);
        return (numberOfEmployees > 0) ? getTotalEmission() / numberOfEmployees : 0;
    }

    @Override
    public String toString() {
        return name;
    }
}
