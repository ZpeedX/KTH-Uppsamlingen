package iv1300.dao;

import iv1300.model.Company;
import iv1300.model.Employee;
import iv1300.model.Person;
import iv1300.util.SqlConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Christoffer on 2016-09-26.
 */
public class EmployeeDAO {

    private static EmployeeDAO instance = new EmployeeDAO();

    private EmployeeDAO() {
    }

    /**
     * The only way of reaching the singleton instance.
     *
     * @return the singleton instance of this class
     */
    public static EmployeeDAO getInstance() {
        return instance;
    }

    /**
     * <br>
     * The local instance of the connection to the
     * database retrieved from {@link SqlConnection}.
     */
    private Connection connection = SqlConnection.getInstance().getCon();

    /**
     * Fetches all of the employees in the database through the {@link #connection}.
     *
     * @return an {@link ObservableList ObservableList&lt;E&gt;} containing instances
     * of {@link Employee}.
     */
    public ObservableList<Employee> getAll() {

        ObservableList<Employee> employees = FXCollections.observableArrayList();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM anställd");

            while (resultSet.next()) {
                employees.add(new Employee(resultSet.getInt("id"),
                        resultSet.getString("förnamn"),
                        resultSet.getString("efternamn"),
                        resultSet.getString("telefonnummer"),
                        resultSet.getString("email")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employees;
    }

    /**
     * Fetching the employees working for company through {@link #getEmployeesForCompany(int)}.
     *
     * @param company the company with the employees.
     * @return an {@link ObservableList ObservableList&lt;E&gt;} containing instances
     * of {@link Employee}.
     * @see #getEmployeesForCompany(int) getEmployeesForCompany(int id)
     */
    public ObservableList<Employee> getEmployeesForCompany(Company company) {
        return getEmployeesForCompany(company.getId());
    }

    /**
     * Fetching the employees working for company by querying the database.
     * This is done through the {@link #connection}.
     *
     * @param id the id of the company
     * @return an {@link ObservableList ObservableList&lt;E&gt;} containing instances
     * of {@link Employee}.
     */
    public ObservableList<Employee> getEmployeesForCompany(int id) {

        ObservableList<Employee> employees = FXCollections.observableArrayList();

        try {
            PreparedStatement preparedStatement =
                    connection.prepareStatement("SELECT a.id, a.förnamn, a.efternamn, a.telefonnummer, a.email " +
                    "FROM Anställd AS a, Företag AS f " +
                    "WHERE f.id = ? AND a.företag = f.id");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                employees.add(new Employee(resultSet.getInt("id"),
                        resultSet.getString("förnamn"),
                        resultSet.getString("efternamn"),
                        resultSet.getString("telefonnummer"),
                        resultSet.getString("email")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }

    /**
     * Inserts an employee into the database through the {@link #connection}.
     *
     * @param company the company which the employee is working for.
     * @param person the credentials of the employee.
     * @return The id of the employee inserted. Returns <code>-1</code> if key wasn't retrieved.
     */
    public int insertEmployee(Company company, Person person) {
        try {
            PreparedStatement preparedStatement =
                    connection.prepareStatement("INSERT INTO anställd (företag,förnamn,efternamn,telefonnummer,email) " +
                    "VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setInt(1, company.getId());
            preparedStatement.setString(2, person.getFirstName());
            preparedStatement.setString(3, person.getLastName());
            preparedStatement.setString(4, person.getPhoneNumber());
            preparedStatement.setString(5, person.getEMail());

            preparedStatement.executeUpdate();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Fetches the total emission of a company through the {@link #connection}.
     *
     * @param id the id of the company.
     * @return If a row was retrieved the value of that row is returned.
     * If no rows match, <code style="color: #6897BB";>0</code> is returned.
     */
    public float getTotalEmissionForEmployee(int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT tot " +
                    "FROM (SELECT a.id, SUM(kilometer * kilometerutsläpp * antal) AS tot " +
                    "FROM anställd AS a, anställdresa AS ar, resa AS r, sträcka AS s, fordon AS f " +
                    "WHERE a.id = anställd AND r.id = resa AND s.id = sträcka AND f.id = fordon " +
                    "GROUP BY a.id) AS t1 " +
                    "WHERE id = ?");

            preparedStatement.setInt(1,id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                return resultSet.getFloat(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.f;
    }
}
