package iv1300.model;

/**
 * Created by Christoffer on 2016-10-06.
 */
public class Distance {

    private int id;
    private float dist;

    /**
     * The constructor for {@link Distance}.
     *
     * @param id the id of the distance
     * @param dist the actual distance in kilometers.
     */
    public Distance(int id, float dist) {
        this.id = id;
        this.dist = dist;
    }

    /**
     * @return the id of the instance called upon.
     */
    public int getId() {
        return id;
    }

    /**
     * @return the distance of the instance called upon
     */
    public float getDist() {
        return dist;
    }
}
