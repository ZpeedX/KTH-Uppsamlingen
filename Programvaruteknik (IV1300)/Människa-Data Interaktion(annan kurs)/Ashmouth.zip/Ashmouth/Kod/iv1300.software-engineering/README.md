# iv1300.software-engineering
Software project of the IV1300 'Programvaruteknik/Software Engineering' course
