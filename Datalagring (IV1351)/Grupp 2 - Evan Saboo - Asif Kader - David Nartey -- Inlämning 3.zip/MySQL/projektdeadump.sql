CREATE DATABASE  IF NOT EXISTS `projektdea` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `projektdea`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: projektdea
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `enhet`
--

DROP TABLE IF EXISTS `enhet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enhet` (
  `namn` varchar(45) NOT NULL,
  PRIMARY KEY (`namn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enhet`
--

LOCK TABLES `enhet` WRITE;
/*!40000 ALTER TABLE `enhet` DISABLE KEYS */;
INSERT INTO `enhet` VALUES ('centiliter'),('gram'),('kg'),('liter');
/*!40000 ALTER TABLE `enhet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grovindelning`
--

DROP TABLE IF EXISTS `grovindelning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grovindelning` (
  `namn` varchar(45) NOT NULL,
  PRIMARY KEY (`namn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grovindelning`
--

LOCK TABLES `grovindelning` WRITE;
/*!40000 ALTER TABLE `grovindelning` DISABLE KEYS */;
INSERT INTO `grovindelning` VALUES ('DRYCK'),('FISK'),('KÖTT'),('OST'),('PASTA'),('SNACKS');
/*!40000 ALTER TABLE `grovindelning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori` (
  `namn` varchar(45) NOT NULL,
  PRIMARY KEY (`namn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori`
--

LOCK TABLES `kategori` WRITE;
/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
INSERT INTO `kategori` VALUES ('glutenfri'),('laktosfri'),('miljövänlig');
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `märke`
--

DROP TABLE IF EXISTS `märke`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `märke` (
  `namn` varchar(45) NOT NULL,
  PRIMARY KEY (`namn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `märke`
--

LOCK TABLES `märke` WRITE;
/*!40000 ALTER TABLE `märke` DISABLE KEYS */;
INSERT INTO `märke` VALUES ('Arla'),('Estrella'),('KLÖVER'),('OLW');
/*!40000 ALTER TABLE `märke` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produkt`
--

DROP TABLE IF EXISTS `produkt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produkt` (
  `namn` varchar(45) NOT NULL,
  `märkesnamn` varchar(45) NOT NULL,
  `grovnamn` varchar(45) NOT NULL,
  `enhetsnamn` varchar(45) NOT NULL,
  PRIMARY KEY (`namn`,`märkesnamn`),
  KEY `märkesnamn_idx` (`märkesnamn`),
  KEY `enhetsnamn_idx` (`enhetsnamn`),
  KEY `grovnamn_idx` (`grovnamn`),
  CONSTRAINT `enhetsnamn` FOREIGN KEY (`enhetsnamn`) REFERENCES `enhet` (`namn`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `grovnamn` FOREIGN KEY (`grovnamn`) REFERENCES `grovindelning` (`namn`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `märkesnamn` FOREIGN KEY (`märkesnamn`) REFERENCES `märke` (`namn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produkt`
--

LOCK TABLES `produkt` WRITE;
/*!40000 ALTER TABLE `produkt` DISABLE KEYS */;
INSERT INTO `produkt` VALUES ('CHIPS','OLW','SNACKS','GRAM'),('LAKTOSFRIMJÖLK','ARLA','DRYCK','LITER'),('MJÖLK','KLÖVER','DRYCK','LITER');
/*!40000 ALTER TABLE `produkt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produktförpackning`
--

DROP TABLE IF EXISTS `produktförpackning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produktförpackning` (
  `streckkodsnummer` int(11) NOT NULL,
  `storlek` double NOT NULL,
  `märke` varchar(45) NOT NULL,
  `produkt` varchar(45) NOT NULL,
  PRIMARY KEY (`streckkodsnummer`),
  KEY `märke_idx` (`märke`,`produkt`),
  CONSTRAINT `märke, produkt` FOREIGN KEY (`märke`, `produkt`) REFERENCES `produkt` (`märkesnamn`, `namn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produktförpackning`
--

LOCK TABLES `produktförpackning` WRITE;
/*!40000 ALTER TABLE `produktförpackning` DISABLE KEYS */;
INSERT INTO `produktförpackning` VALUES (123456788,350,'OLW','CHIPS'),(123456789,1,'ARLA','LAKTOSFRIMJÖLK');
/*!40000 ALTER TABLE `produktförpackning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produktkategori`
--

DROP TABLE IF EXISTS `produktkategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produktkategori` (
  `kategorinamn` varchar(45) NOT NULL,
  `produktnamn` varchar(45) NOT NULL,
  `produktmärke` varchar(45) NOT NULL,
  PRIMARY KEY (`kategorinamn`,`produktnamn`,`produktmärke`),
  KEY `produktmärke_idx` (`produktmärke`,`produktnamn`),
  CONSTRAINT `kategorinamn` FOREIGN KEY (`kategorinamn`) REFERENCES `kategori` (`namn`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `produktmärke,produktnamn` FOREIGN KEY (`produktmärke`, `produktnamn`) REFERENCES `produkt` (`märkesnamn`, `namn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produktkategori`
--

LOCK TABLES `produktkategori` WRITE;
/*!40000 ALTER TABLE `produktkategori` DISABLE KEYS */;
INSERT INTO `produktkategori` VALUES ('LAKTOSFRI','LAKTOSFRIMJÖLK','ARLA');
/*!40000 ALTER TABLE `produktkategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'projektdea'
--

--
-- Dumping routines for database 'projektdea'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-06 18:43:56
